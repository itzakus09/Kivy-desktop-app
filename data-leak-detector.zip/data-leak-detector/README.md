# Personal Data Leak Detector

An AI-powered security desktop application that scans PDF documents for sensitive and personally identifiable information (PII), combining fast rule-based pattern detection with contextual AI analysis via the Claude API — then gives you a clear risk score and actionable remediation steps.

## Features

- **Local-first PDF extraction** — the PDF file itself never leaves your machine; only extracted text is sent onward
- **Hybrid detection engine** — regex/checksum-based rule detectors (email, phone, credit card w/ Luhn validation, bank account, PAN, Aadhaar w/ Verhoeff checksum, IP address, URL, password, API key, auth token, date of birth, address) merged with Claude-powered contextual analysis
- **Real-time progress** over WebSocket — extraction, rule scan, AI analysis, and recommendations stream live to the UI, no frozen windows
- **Risk scoring (0–100)** with LOW / MEDIUM / HIGH / CRITICAL levels, weighted by severity, confidence, category sensitivity, credential/financial presence, and repetition
- **Data-minimized AI calls** — only rule-flagged excerpts (or the full text for short documents) are sent to Claude, never the raw PDF
- **Graceful degradation** — if the AI service is unavailable, misconfigured, or rate-limited, the scan still completes using rule-based results only
- **Security-conscious logging** — passwords, API keys, and other sensitive values are always masked in logs and in the UI

## Architecture

```mermaid
flowchart LR
    subgraph Desktop["Kivy Desktop App (Python)"]
        A[Select PDF] --> B[PyMuPDF: Extract Text]
        B --> C[Local Optimistic Pre-scan]
        C --> D[WebSocket Client]
    end

    subgraph Backend["Node.js Backend"]
        E[WebSocket Server] --> F[Rule-Based Detectors]
        F --> G[Claude Service]
        G --> H[Risk + Recommendation Engine]
    end

    subgraph AI["Anthropic Claude API"]
        I[Contextual Security Analysis]
    end

    D <-->|events: upload_started, rule_scan_completed,\nai_analysis_completed, scan_completed, error| E
    G -->|extracted excerpts only, never the raw PDF| I
    I --> G
    H --> D
    D --> J[Results Dashboard]
```

## Technology Stack

| Layer | Tech |
|---|---|
| Desktop UI | Python, Kivy |
| PDF extraction | PyMuPDF |
| Backend | Node.js, Express |
| Real-time | WebSocket (`ws`) |
| AI analysis | Anthropic Claude API |

## Project Structure

```
data-leak-detector/
├── backend/            # Node.js + Express + WebSocket server
│   ├── server.js
│   ├── routes/
│   ├── services/        # claudeService, pdfService, recommendationService, riskService
│   ├── detectors/        # one module per detection category
│   ├── websocket/
│   ├── middleware/
│   ├── utils/
│   ├── schemas/
│   └── tests/
└── desktop/             # Kivy client
    ├── main.py
    ├── ui/
    ├── services/
    ├── models/
    ├── utils/
    └── tests/
```

## Installation

### Prerequisites

- Node.js 18+
- Python 3.10+
- An Anthropic API key ([console.anthropic.com](https://console.anthropic.com))

### Backend Setup

```bash
cd backend
npm install
cp .env.example .env
# edit .env and set ANTHROPIC_API_KEY
npm start
```

The backend listens on `http://localhost:4000` (REST) and `ws://localhost:4000/ws` (WebSocket) by default.

### Desktop App Setup

```bash
cd desktop
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

By default the desktop app connects to `ws://localhost:4000/ws`. Override with environment variables if your backend runs elsewhere:

```bash
export BACKEND_HTTP_URL=http://your-backend-host:4000
export BACKEND_WS_URL=ws://your-backend-host:4000/ws
```

## Environment Variables (backend/.env)

| Variable | Description | Default |
|---|---|---|
| `PORT` | Backend HTTP/WS port | `4000` |
| `ANTHROPIC_API_KEY` | Your Claude API key | — (required for AI analysis) |
| `CLAUDE_MODEL` | Claude model to use | `claude-sonnet-5` |
| `CLAUDE_MAX_TOKENS` | Max tokens for the AI response | `2000` |
| `MAX_UPLOAD_TEXT_CHARS` | Below this, full text is sent to Claude; above it, only flagged excerpts | `6000` |
| `MAX_FILE_SIZE_MB` | Max accepted PDF size | `25` |
| `AI_CONTEXT_WINDOW_SENTENCES` | Sentences of context per excerpt sent to Claude | `2` |
| `ALLOWED_ORIGIN` | CORS origin | `*` |

## Example Workflow

1. Launch the backend (`npm start`) and the desktop app (`python main.py`)
2. Click **Select PDF**, choose a document, then **Scan Document**
3. Watch the live progress bar move through extraction → rule scan → AI analysis → recommendations
4. Review the **Results Dashboard**: overall risk score/level, category breakdown, detailed findings (each with severity, confidence, page, and a specific remediation step), and a prioritized recommendation list

## Privacy & Security Considerations

- The original PDF file is **never uploaded** to the backend or to Claude — only extracted text, and even then only the minimum needed (full text for short documents, flagged excerpts for longer ones)
- No database or persistent storage — each scan lives in memory only, cleared on completion or error
- Sensitive values (passwords, API keys, card numbers, ID numbers) are **always masked** before being logged or displayed — raw values never appear in logs
- All AI responses are schema-validated before use; malformed or unexpected responses are rejected, not silently trusted

## API Structure (Backend)

- `GET /health` — service + AI-configuration status
- `POST /api/scan/init` — (optional) pre-allocate a scan ID
- `GET /api/scan/:id/report` — fetch a completed report if the WebSocket connection dropped
- `WS /ws` — primary scan channel; client sends `{"type": "start_scan", "meta": {...}, "pages": [...]}`, server streams progress events and a final `scan_completed` event with the full report

## Testing

```bash
# Backend — 15 unit tests covering all detectors, false-positive avoidance, and risk scoring
cd backend && npm test

# Desktop — validation and PDF extraction tests
cd desktop && python -m unittest discover tests -v
```

Both suites are green as of this build; the full pipeline has also been verified end-to-end (real PDF → real extraction → real WebSocket round-trip → real backend detectors → rendered report).

## Future Improvements

- OCR support for scanned/image-only PDFs
- SQLite-backed scan history (currently intentionally stateless)
- Batch scanning of multiple documents
- Configurable custom regex detectors via a UI settings panel
- Automatic redaction: export a sanitized copy of the PDF with findings blacked out
