'use strict';

const ALLOWED_EXTENSIONS = new Set(['.pdf']);
const DEFAULT_MAX_SIZE_MB = 25;

class ValidationError extends Error {
  constructor(message, code) {
    super(message);
    this.code = code || 'VALIDATION_ERROR';
  }
}

function validateFileMeta(meta, maxSizeMb = DEFAULT_MAX_SIZE_MB) {
  if (!meta || typeof meta !== 'object') {
    throw new ValidationError('Missing file metadata.', 'MISSING_META');
  }
  const { filename, sizeBytes } = meta;
  if (!filename || typeof filename !== 'string') {
    throw new ValidationError('Missing filename.', 'MISSING_FILENAME');
  }
  const ext = filename.slice(filename.lastIndexOf('.')).toLowerCase();
  if (!ALLOWED_EXTENSIONS.has(ext)) {
    throw new ValidationError(`Unsupported file type "${ext}". Only PDF files are supported.`, 'UNSUPPORTED_TYPE');
  }
  if (typeof sizeBytes === 'number' && sizeBytes > maxSizeMb * 1024 * 1024) {
    throw new ValidationError(`File exceeds the ${maxSizeMb}MB size limit.`, 'FILE_TOO_LARGE');
  }
  return true;
}

/** Express middleware for the REST init endpoint. */
function validateScanInit(req, res, next) {
  try {
    validateFileMeta(req.body?.meta, Number(process.env.MAX_FILE_SIZE_MB) || DEFAULT_MAX_SIZE_MB);
    next();
  } catch (err) {
    res.status(400).json({ error: err.message, code: err.code });
  }
}

module.exports = { validateFileMeta, validateScanInit, ValidationError };
