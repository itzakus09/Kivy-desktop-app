'use strict';

/**
 * Lightweight logger that automatically masks known-sensitive field names
 * and never prints full document contents.
 */

const SENSITIVE_KEYS = new Set([
  'password', 'apiKey', 'api_key', 'token', 'authToken', 'auth_token',
  'creditCard', 'credit_card', 'bankAccount', 'bank_account',
  'aadhaar', 'pan', 'ssn', 'fullText', 'rawText', 'documentText', 'text'
]);

function maskValue(value) {
  if (typeof value !== 'string') return value;
  if (value.length <= 4) return '****';
  return `${'*'.repeat(Math.max(value.length - 4, 4))}${value.slice(-4)}`;
}

function sanitize(obj, seen = new WeakSet()) {
  if (obj === null || typeof obj !== 'object') return obj;
  if (seen.has(obj)) return '[circular]';
  seen.add(obj);

  if (Array.isArray(obj)) return obj.map((item) => sanitize(item, seen));

  const out = {};
  for (const [key, value] of Object.entries(obj)) {
    if (SENSITIVE_KEYS.has(key)) {
      out[key] = typeof value === 'string' ? maskValue(value) : '[redacted]';
    } else if (value && typeof value === 'object') {
      out[key] = sanitize(value, seen);
    } else {
      out[key] = value;
    }
  }
  return out;
}

function timestamp() {
  return new Date().toISOString();
}

const logger = {
  info(message, meta) {
    console.log(`[INFO ${timestamp()}] ${message}`, meta ? sanitize(meta) : '');
  },
  warn(message, meta) {
    console.warn(`[WARN ${timestamp()}] ${message}`, meta ? sanitize(meta) : '');
  },
  error(message, meta) {
    console.error(`[ERROR ${timestamp()}] ${message}`, meta ? sanitize(meta) : '');
  },
  debug(message, meta) {
    if (process.env.NODE_ENV !== 'production') {
      console.debug(`[DEBUG ${timestamp()}] ${message}`, meta ? sanitize(meta) : '');
    }
  }
};

module.exports = { logger, sanitize, maskValue };
