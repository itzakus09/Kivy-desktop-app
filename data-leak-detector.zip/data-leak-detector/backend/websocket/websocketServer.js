'use strict';

const { WebSocketServer } = require('ws');
const crypto = require('crypto');

const { logger } = require('../utils/logger');
const { runAllDetectors } = require('../detectors');
const { validatePages, isEffectivelyEmpty, PdfTextValidationError } = require('../services/pdfService');
const { computeRisk } = require('../services/riskService');
const { buildAiContext, mergeRecommendations, categoryBreakdown } = require('../services/recommendationService');
const { analyzeWithClaude, ClaudeServiceError } = require('../services/claudeService');
const { validateFileMeta, ValidationError } = require('../middleware/validation');
const { cacheReport } = require('../routes/scanRoutes');

// In-memory scan state, keyed by scanId. No persistence — cleared as
// soon as a scan completes or errors, per the "no unnecessary document
// persistence" requirement.
const activeScans = new Map();

function send(ws, event, payload = {}) {
  if (ws.readyState !== ws.OPEN) return;
  ws.send(JSON.stringify({ event, timestamp: new Date().toISOString(), ...payload }));
}

function newScanId() {
  return crypto.randomBytes(8).toString('hex');
}

async function handleScanMessage(ws, message) {
  const { meta, pages } = message;
  const scanId = newScanId();
  activeScans.set(scanId, { startedAt: Date.now() });

  try {
    send(ws, 'upload_started', { scanId, progress: 5, message: 'Upload received.', data: { filename: meta?.filename } });

    validateFileMeta(meta, Number(process.env.MAX_FILE_SIZE_MB) || 25);

    send(ws, 'extraction_started', { scanId, progress: 15, message: 'Preparing extracted text for scanning.' });

    validatePages(pages);
    if (isEffectivelyEmpty(pages)) {
      throw new PdfTextValidationError('This PDF appears to be empty or contains only images (no extractable text).');
    }

    send(ws, 'extraction_completed', {
      scanId, progress: 30, message: 'Text ready.',
      data: { pageCount: pages.length, charCount: pages.reduce((s, p) => s + p.text.length, 0) }
    });

    send(ws, 'rule_scan_started', { scanId, progress: 40, message: 'Running rule-based detectors.' });
    const ruleFindings = runAllDetectors(pages);
    send(ws, 'rule_scan_completed', {
      scanId, progress: 55, message: `Rule-based scan found ${ruleFindings.length} item(s).`,
      data: { findings: ruleFindings }
    });

    send(ws, 'ai_analysis_started', { scanId, progress: 70, message: 'Running AI contextual analysis.' });

    let aiFindings = [];
    let aiSummary = '';
    let aiRecommendations = [];
    try {
      const maxChars = Number(process.env.MAX_UPLOAD_TEXT_CHARS) || 6000;
      const contextSentences = Number(process.env.AI_CONTEXT_WINDOW_SENTENCES) || 2;
      const aiContextPages = buildAiContext(pages, ruleFindings, { maxChars, contextSentences });

      const categories = [...new Set(ruleFindings.map((f) => f.category))];
      const claudeResult = await analyzeWithClaude({
        apiKey: process.env.ANTHROPIC_API_KEY,
        model: process.env.CLAUDE_MODEL || 'claude-sonnet-5',
        maxTokens: Number(process.env.CLAUDE_MAX_TOKENS) || 2000,
        pages: aiContextPages,
        ruleFindingSummary: { count: ruleFindings.length, categories }
      });

      aiFindings = claudeResult.findings.map((f) => ({
        id: crypto.randomBytes(6).toString('hex'),
        category: f.category || 'OTHER',
        description: f.description,
        severity: f.severity,
        confidence: f.confidence,
        page: f.page ?? null,
        source: 'ai',
        maskedValue: '[see description]',
        recommendation: f.recommendation
      }));
      aiSummary = claudeResult.summary;
      aiRecommendations = claudeResult.recommendations;

      send(ws, 'ai_analysis_completed', {
        scanId, progress: 85, message: `AI analysis found ${aiFindings.length} additional item(s).`,
        data: { findings: aiFindings, summary: aiSummary }
      });
    } catch (err) {
      // AI failure should degrade gracefully, not kill the whole scan —
      // the rule-based results are still a valid, complete report.
      const code = err instanceof ClaudeServiceError ? err.code : 'AI_UNKNOWN_ERROR';
      logger.warn('Claude analysis unavailable, continuing with rule-based results only', { code, message: err.message });
      send(ws, 'ai_analysis_completed', {
        scanId, progress: 85,
        message: `AI analysis unavailable (${code}); showing rule-based results only.`,
        data: { findings: [], degraded: true, reason: code }
      });
    }

    const allFindings = [...ruleFindings, ...aiFindings];
    const { riskScore, riskLevel } = computeRisk(allFindings);
    const recommendations = mergeRecommendations(allFindings, aiRecommendations);
    const categories = categoryBreakdown(allFindings);

    send(ws, 'recommendations_generated', {
      scanId, progress: 92, message: 'Recommendations ready.', data: { recommendations }
    });

    const report = {
      scanId,
      filename: meta?.filename,
      completedAt: new Date().toISOString(),
      riskScore,
      riskLevel,
      categories,
      findings: allFindings,
      recommendations,
      aiSummary: aiSummary || null
    };

    cacheReport(report);
    send(ws, 'scan_completed', { scanId, progress: 100, message: 'Scan complete.', data: report });
  } catch (err) {
    const code = err.code || (err instanceof PdfTextValidationError ? 'INVALID_PDF_TEXT' : 'SCAN_FAILED');
    logger.error('Scan failed', { scanId, code, message: err.message });
    send(ws, 'error', {
      scanId,
      message: humanizeError(code, err.message),
      code,
      recoverable: err instanceof ClaudeServiceError ? err.recoverable : false
    });
  } finally {
    activeScans.delete(scanId);
  }
}

function humanizeError(code, fallback) {
  const messages = {
    UNSUPPORTED_TYPE: 'Only PDF files are supported.',
    FILE_TOO_LARGE: 'This file is larger than the allowed upload size.',
    INVALID_PDF_TEXT: 'This PDF could not be read — it may be empty, corrupted, or image-only.',
    MISSING_API_KEY: 'The AI analysis service is not configured on the server.',
    INVALID_API_KEY: 'The AI analysis service rejected the configured API key.',
    RATE_LIMITED: 'The AI analysis service is temporarily rate-limited. Please try again shortly.',
    TIMEOUT: 'The AI analysis service took too long to respond.',
    UPSTREAM_UNAVAILABLE: 'The AI analysis service is temporarily unavailable.'
  };
  return messages[code] || fallback || 'An unexpected error occurred during the scan.';
}

function attachWebSocketServer(httpServer) {
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws) => {
    send(ws, 'connected', { message: 'Connected to Personal Data Leak Detector backend.' });

    ws.on('message', async (raw) => {
      let message;
      try {
        message = JSON.parse(raw.toString());
      } catch {
        send(ws, 'error', { message: 'Malformed message received.', code: 'BAD_MESSAGE', recoverable: false });
        return;
      }

      if (message.type === 'start_scan') {
        await handleScanMessage(ws, message);
      } else {
        send(ws, 'error', { message: `Unknown message type "${message.type}".`, code: 'UNKNOWN_TYPE', recoverable: false });
      }
    });

    ws.on('error', (err) => logger.error('WebSocket connection error', { message: err.message }));
  });

  logger.info('WebSocket server attached at /ws');
  return wss;
}

module.exports = { attachWebSocketServer, activeScans };
