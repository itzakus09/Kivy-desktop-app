'use strict';

require('dotenv').config();

const express = require('express');
const http = require('http');
const cors = require('cors');

const { logger } = require('./utils/logger');
const { router: scanRoutes } = require('./routes/scanRoutes');
const { attachWebSocketServer } = require('./websocket/websocketServer');

const PORT = process.env.PORT || 4000;

const app = express();
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || '*' }));
app.use(express.json({ limit: '15mb' })); // extracted text payloads can be sizeable; still far smaller than the PDF itself

app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    aiConfigured: Boolean(process.env.ANTHROPIC_API_KEY),
    uptimeSeconds: Math.round(process.uptime())
  });
});

app.use('/api/scan', scanRoutes);

// Generic error handler — never leak stack traces to the client.
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  logger.error('Unhandled request error', { message: err.message });
  res.status(500).json({ error: 'An unexpected server error occurred.', code: 'INTERNAL_ERROR' });
});

const httpServer = http.createServer(app);
attachWebSocketServer(httpServer);

httpServer.listen(PORT, () => {
  logger.info(`Personal Data Leak Detector backend listening on port ${PORT}`);
  if (!process.env.ANTHROPIC_API_KEY) {
    logger.warn('ANTHROPIC_API_KEY is not set — AI analysis will be skipped and scans will fall back to rule-based results only.');
  }
});

module.exports = { app, httpServer };
