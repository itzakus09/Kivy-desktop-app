'use strict';

// Not in the original file list, but IP_ADDRESS and URL are listed as
// required categories in the spec — grouped here since they share the
// same "network identifier" concern rather than forcing them into an
// unrelated detector file.

const { buildFinding, maskGeneric } = require('./baseDetector');

const IP_RE = /\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b/g;
const URL_RE = /\bhttps?:\/\/[^\s"'<>]+/gi;

function run(text, page) {
  const findings = [];

  const seenIp = new Set();
  let match;
  IP_RE.lastIndex = 0;
  while ((match = IP_RE.exec(text)) !== null) {
    const value = match[0];
    if (seenIp.has(value)) continue;
    seenIp.add(value);
    if (value === '127.0.0.1' || value.startsWith('0.')) continue; // skip obviously local/placeholder
    findings.push(buildFinding({
      category: 'IP_ADDRESS',
      description: 'IP address detected.',
      severity: 'LOW',
      confidence: 0.85,
      page,
      maskedValue: maskGeneric(value),
      recommendation: 'Confirm whether this IP address needs to be shared; mask it if it reveals internal infrastructure.'
    }));
  }

  const seenUrl = new Set();
  URL_RE.lastIndex = 0;
  while ((match = URL_RE.exec(text)) !== null) {
    const value = match[0];
    if (seenUrl.has(value)) continue;
    seenUrl.add(value);
    // Flag only if URL itself embeds a token/credential-looking query param
    const risky = /(token|key|secret|password|auth)=/i.test(value);
    findings.push(buildFinding({
      category: 'URL',
      description: risky
        ? 'URL detected that appears to embed a credential or token in its query string.'
        : 'URL detected.',
      severity: risky ? 'HIGH' : 'LOW',
      confidence: risky ? 0.85 : 0.6,
      page,
      maskedValue: risky ? maskGeneric(value) : value,
      recommendation: risky
        ? 'Rotate the embedded credential and remove it from the URL before sharing.'
        : 'Review whether this URL should be shared publicly.'
    }));
  }

  return findings;
}

module.exports = { category: 'NETWORK', run };
