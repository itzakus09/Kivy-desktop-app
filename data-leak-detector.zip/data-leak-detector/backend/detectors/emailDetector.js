'use strict';

const { buildFinding, maskGeneric } = require('./baseDetector');

const EMAIL_RE = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g;

function maskEmail(value) {
  const [local, domain] = value.split('@');
  if (!domain) return maskGeneric(value);
  const maskedLocal = local.length <= 2 ? '*'.repeat(local.length) : `${local[0]}${'*'.repeat(local.length - 2)}${local[local.length - 1]}`;
  return `${maskedLocal}@${domain}`;
}

function run(text, page) {
  const findings = [];
  const seen = new Set();
  let match;
  EMAIL_RE.lastIndex = 0;
  while ((match = EMAIL_RE.exec(text)) !== null) {
    const value = match[0];
    if (seen.has(value)) continue;
    seen.add(value);
    findings.push(buildFinding({
      category: 'EMAIL',
      description: 'Email address detected.',
      severity: 'LOW',
      confidence: 0.95,
      page,
      maskedValue: maskEmail(value),
      recommendation: 'Remove or mask the email address if it is not needed by the recipient of this document.'
    }));
  }
  return findings;
}

module.exports = { category: 'EMAIL', run };
