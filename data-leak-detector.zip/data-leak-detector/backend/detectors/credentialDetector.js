'use strict';

const { buildFinding, maskGeneric } = require('./baseDetector');

// Common API key / token shapes (AWS, GitHub, Stripe, generic bearer/JWT, generic hex secrets)
const API_KEY_PATTERNS = [
  { re: /\bAKIA[0-9A-Z]{16}\b/g, label: 'AWS Access Key' },
  { re: /\bgh[pousr]_[A-Za-z0-9]{36,}\b/g, label: 'GitHub Token' },
  { re: /\bsk_(live|test)_[A-Za-z0-9]{16,}\b/g, label: 'Stripe Secret Key' },
  { re: /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g, label: 'JWT' },
  { re: /\b(?:[A-Za-z0-9+/]{40,}={0,2})\b/g, label: 'Generic base64-like secret' }
];

const AUTH_TOKEN_CONTEXT_RE = /(bearer|authorization|auth[_-]?token|access[_-]?token)/i;
const PASSWORD_RE = /(password|passwd|pwd)\s*[:=]\s*\S+/gi;

function run(text, page) {
  const findings = [];

  for (const { re, label } of API_KEY_PATTERNS) {
    re.lastIndex = 0;
    let match;
    const seen = new Set();
    while ((match = re.exec(text)) !== null) {
      const value = match[0];
      if (seen.has(value)) continue;
      seen.add(value);
      findings.push(buildFinding({
        category: 'API_KEY',
        description: `Potential ${label} detected.`,
        severity: 'CRITICAL',
        confidence: label === 'Generic base64-like secret' ? 0.5 : 0.9,
        page,
        maskedValue: maskGeneric(value),
        recommendation: 'Revoke and regenerate this credential immediately; treat it as compromised.'
      }));
    }
  }

  // Bearer/auth tokens by context rather than shape
  let m;
  const authRe = /\b[A-Za-z0-9_-]{20,}\b/g;
  while ((m = authRe.exec(text)) !== null) {
    const windowStart = Math.max(0, m.index - 25);
    const contextWindow = text.slice(windowStart, m.index);
    if (!AUTH_TOKEN_CONTEXT_RE.test(contextWindow)) continue;
    findings.push(buildFinding({
      category: 'AUTH_TOKEN',
      description: 'Authentication token detected near authorization-related context.',
      severity: 'CRITICAL',
      confidence: 0.75,
      page,
      maskedValue: maskGeneric(m[0]),
      recommendation: 'Revoke this token and rotate credentials for the associated service.'
    }));
  }

  // Passwords by key=value / key: value pattern
  PASSWORD_RE.lastIndex = 0;
  let pMatch;
  while ((pMatch = PASSWORD_RE.exec(text)) !== null) {
    findings.push(buildFinding({
      category: 'PASSWORD',
      description: 'Password-like string detected.',
      severity: 'CRITICAL',
      confidence: 0.85,
      page,
      maskedValue: '********',
      recommendation: 'Rotate this password immediately and never store credentials in plain documents.'
    }));
  }

  return findings;
}

module.exports = { category: 'CREDENTIAL', run };
