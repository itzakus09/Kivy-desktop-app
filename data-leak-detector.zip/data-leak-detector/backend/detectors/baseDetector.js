'use strict';

const crypto = require('crypto');

/**
 * Common helpers shared by every detector: id generation, masking, and a
 * uniform finding builder so each detector file only has to supply the
 * regex + validation logic that's specific to it.
 */

function makeId() {
  return crypto.randomBytes(6).toString('hex');
}

function maskGeneric(value) {
  if (value.length <= 4) return '*'.repeat(value.length);
  return `${'*'.repeat(value.length - 4)}${value.slice(-4)}`;
}

/**
 * Finds the sentence/line containing `index` in `text`, used to estimate
 * which page a match belongs to when the caller passes page-tagged chunks.
 */
function buildFinding({ category, description, severity, confidence, page, source, maskedValue, recommendation }) {
  return {
    id: makeId(),
    category,
    description,
    severity,
    confidence,
    page: page ?? null,
    source: source || 'rule_based',
    maskedValue,
    recommendation
  };
}

module.exports = { makeId, maskGeneric, buildFinding };
