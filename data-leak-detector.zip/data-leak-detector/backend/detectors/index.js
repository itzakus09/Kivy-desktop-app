'use strict';

const emailDetector = require('./emailDetector');
const phoneDetector = require('./phoneDetector');
const financialDetector = require('./financialDetector');
const identityDetector = require('./identityDetector');
const credentialDetector = require('./credentialDetector');
const networkDetector = require('./networkDetector');

const ALL_DETECTORS = [
  emailDetector, phoneDetector, financialDetector,
  identityDetector, credentialDetector, networkDetector
];

/**
 * Runs every detector against every page of extracted text.
 * @param {Array<{page: number, text: string}>} pages
 * @returns {Array<Finding>}
 */
function runAllDetectors(pages) {
  const findings = [];
  for (const { page, text } of pages) {
    if (!text || !text.trim()) continue;
    for (const detector of ALL_DETECTORS) {
      try {
        findings.push(...detector.run(text, page));
      } catch (err) {
        // A single bad detector should never take down the whole scan.
        // eslint-disable-next-line no-console
        console.error(`Detector ${detector.category} failed on page ${page}:`, err.message);
      }
    }
  }
  return findings;
}

module.exports = { runAllDetectors, ALL_DETECTORS };
