'use strict';

const { buildFinding, maskGeneric } = require('./baseDetector');

const PAN_RE = /\b[A-Z]{5}[0-9]{4}[A-Z]\b/g;
const PAN_CONTEXT_RE = /(pan|permanent account number)/i;

const AADHAAR_RE = /\b\d{4}[ -]?\d{4}[ -]?\d{4}\b/g;
const AADHAAR_CONTEXT_RE = /(aadhaar|aadhar|uidai|unique identification)/i;

const DOB_CONTEXT_RE = /(dob|date of birth|born on|birth date)/i;
const DATE_RE = /\b(\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}|\d{4}[\/\-.]\d{1,2}[\/\-.]\d{1,2})\b/g;

// Basic Indian-address style heuristic: presence of a pincode near
// address-context keywords. Full address extraction is intentionally left
// to the AI layer, which handles free-text context far better than regex.
const ADDRESS_CONTEXT_RE = /(address|residing at|street|road|colony|sector|near)/i;
const PINCODE_RE = /\b\d{6}\b/g;

// Verhoeff checksum tables — used for genuine Aadhaar-number validation
// rather than a naive "12 digits = Aadhaar" rule.
const VERHOEFF_D = [
  [0,1,2,3,4,5,6,7,8,9],[1,2,3,4,0,6,7,8,9,5],[2,3,4,0,1,7,8,9,5,6],
  [3,4,0,1,2,8,9,5,6,7],[4,0,1,2,3,9,5,6,7,8],[5,9,8,7,6,0,4,3,2,1],
  [6,5,9,8,7,1,0,4,3,2],[7,6,5,9,8,2,1,0,4,3],[8,7,6,5,9,3,2,1,0,4],
  [9,8,7,6,5,4,3,2,1,0]
];
const VERHOEFF_P = [
  [0,1,2,3,4,5,6,7,8,9],[1,5,7,6,2,8,3,0,9,4],[5,8,0,3,7,9,6,1,4,2],
  [8,9,1,6,0,4,3,5,2,7],[9,4,5,3,1,2,6,8,7,0],[4,2,8,6,5,7,3,9,0,1],
  [2,7,9,3,8,0,6,4,1,5],[7,0,4,6,9,1,3,2,5,8]
];

function verhoeffValidate(numStr) {
  let c = 0;
  const digits = numStr.split('').reverse().map(Number);
  for (let i = 0; i < digits.length; i++) {
    c = VERHOEFF_D[c][VERHOEFF_P[i % 8][digits[i]]];
  }
  return c === 0;
}

function run(text, page) {
  const findings = [];

  // PAN
  let match;
  PAN_RE.lastIndex = 0;
  const seenPan = new Set();
  while ((match = PAN_RE.exec(text)) !== null) {
    const value = match[0];
    if (seenPan.has(value)) continue;
    seenPan.add(value);
    const windowStart = Math.max(0, match.index - 40);
    const hasContext = PAN_CONTEXT_RE.test(text.slice(windowStart, match.index + value.length + 10));
    findings.push(buildFinding({
      category: 'PAN',
      description: 'PAN-like identifier detected (no checksum exists for PAN, so this is pattern-based).',
      severity: 'HIGH',
      confidence: hasContext ? 0.85 : 0.55,
      page,
      maskedValue: maskGeneric(value),
      recommendation: 'Redact the PAN before sharing; it is a sensitive tax-identity number in India.'
    }));
  }

  // Aadhaar
  AADHAAR_RE.lastIndex = 0;
  const seenAadhaar = new Set();
  while ((match = AADHAAR_RE.exec(text)) !== null) {
    const digits = match[0].replace(/[ -]/g, '');
    if (digits.length !== 12) continue;
    if (seenAadhaar.has(digits)) continue;
    seenAadhaar.add(digits);
    const validChecksum = verhoeffValidate(digits);
    const windowStart = Math.max(0, match.index - 40);
    const hasContext = AADHAAR_CONTEXT_RE.test(text.slice(windowStart, match.index + digits.length + 10));
    if (!validChecksum && !hasContext) continue; // require at least one strong signal
    findings.push(buildFinding({
      category: 'AADHAAR',
      description: validChecksum
        ? 'Aadhaar-like number detected and passed Verhoeff checksum validation.'
        : 'Aadhaar-like number detected near Aadhaar-related context (checksum did not validate).',
      severity: 'CRITICAL',
      confidence: validChecksum ? 0.92 : 0.6,
      page,
      maskedValue: maskGeneric(digits),
      recommendation: 'Redact the Aadhaar number immediately; it is a high-sensitivity national identity number.'
    }));
  }

  // Date of birth (only when near DOB context keywords)
  DATE_RE.lastIndex = 0;
  while ((match = DATE_RE.exec(text)) !== null) {
    const value = match[0];
    const windowStart = Math.max(0, match.index - 30);
    const hasContext = DOB_CONTEXT_RE.test(text.slice(windowStart, match.index));
    if (!hasContext) continue;
    findings.push(buildFinding({
      category: 'DATE_OF_BIRTH',
      description: 'Date of birth detected near DOB-related context.',
      severity: 'MEDIUM',
      confidence: 0.8,
      page,
      maskedValue: maskGeneric(value),
      recommendation: 'Remove or mask the date of birth if this document does not require it.'
    }));
  }

  // Address (heuristic: pincode near address-context keywords)
  PINCODE_RE.lastIndex = 0;
  while ((match = PINCODE_RE.exec(text)) !== null) {
    const value = match[0];
    const windowStart = Math.max(0, match.index - 60);
    const contextWindow = text.slice(windowStart, match.index + value.length + 10);
    if (!ADDRESS_CONTEXT_RE.test(contextWindow)) continue;
    findings.push(buildFinding({
      category: 'ADDRESS',
      description: 'Possible physical address detected near address-related context.',
      severity: 'MEDIUM',
      confidence: 0.55,
      page,
      maskedValue: '[address redacted]',
      recommendation: 'Review and mask the full address if it is not necessary for this document\u2019s purpose.'
    }));
  }

  return findings;
}

module.exports = { category: 'IDENTITY', run, verhoeffValidate };
