'use strict';

const { buildFinding, maskGeneric } = require('./baseDetector');

// Matches runs of digits that may contain phone-style separators
// (spaces, hyphens, dots, parens, leading +). The run is validated by
// digit count (10-13) after stripping separators, which avoids matching
// arbitrary long numbers (e.g. account IDs) more reliably than trying to
// encode the exact grouping in the regex itself.
const PHONE_RE = /\+?\(?\d{2,5}\)?[\s.-]?\d{2,5}[\s.-]?\d{2,5}(?:[\s.-]?\d{2,5})?/g;

// Context keywords that raise confidence a matched digit string is really
// a phone number rather than some other numeric ID.
const CONTEXT_HINTS = /(phone|mobile|contact|call|tel|whatsapp|cell)/i;

function digitsOnly(s) {
  return s.replace(/\D/g, '');
}

function isPlausiblePhone(digits) {
  return digits.length >= 10 && digits.length <= 13;
}

function maskPhone(value) {
  const digits = digitsOnly(value);
  return `${'*'.repeat(Math.max(digits.length - 4, 0))}${digits.slice(-4)}`;
}

function run(text, page) {
  const findings = [];
  const seen = new Set();
  let match;
  PHONE_RE.lastIndex = 0;
  while ((match = PHONE_RE.exec(text)) !== null) {
    const raw = match[0];
    const digits = digitsOnly(raw);
    if (!isPlausiblePhone(digits)) continue;
    if (seen.has(digits)) continue;
    seen.add(digits);

    const windowStart = Math.max(0, match.index - 30);
    const contextWindow = text.slice(windowStart, match.index + raw.length + 10);
    const hasContext = CONTEXT_HINTS.test(contextWindow);

    findings.push(buildFinding({
      category: 'PHONE',
      description: 'Phone number pattern detected.',
      severity: 'MEDIUM',
      confidence: hasContext ? 0.9 : 0.65,
      page,
      maskedValue: maskPhone(raw),
      recommendation: 'Mask or remove the phone number before sharing this document externally.'
    }));
  }
  return findings;
}

module.exports = { category: 'PHONE', run };
