'use strict';

const { buildFinding, maskGeneric } = require('./baseDetector');

// Credit-card-like sequences: 13-19 digits, optionally grouped with spaces/hyphens.
const CARD_RE = /\b(?:\d[ -]?){13,19}\b/g;
// Indian bank account numbers: typically 9-18 digits, often near "account" context.
const ACCOUNT_CONTEXT_RE = /(account\s*(no|number|#)?|a\/c|acct)/i;
const BANK_ACCOUNT_RE = /\b\d{9,18}\b/g;

function luhnCheck(digits) {
  let sum = 0;
  let alt = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let n = parseInt(digits[i], 10);
    if (alt) {
      n *= 2;
      if (n > 9) n -= 9;
    }
    sum += n;
    alt = !alt;
  }
  return sum % 10 === 0;
}

function maskCard(digits) {
  return `**** **** **** ${digits.slice(-4)}`;
}

function run(text, page) {
  const findings = [];
  const seenCards = new Set();
  let match;

  CARD_RE.lastIndex = 0;
  while ((match = CARD_RE.exec(text)) !== null) {
    const digits = match[0].replace(/[ -]/g, '');
    if (digits.length < 13 || digits.length > 19) continue;
    if (!luhnCheck(digits)) continue; // avoid flagging arbitrary long numbers
    if (seenCards.has(digits)) continue;
    seenCards.add(digits);

    findings.push(buildFinding({
      category: 'CREDIT_CARD',
      description: 'Credit/debit card-like number detected (passed Luhn checksum).',
      severity: 'CRITICAL',
      confidence: 0.93,
      page,
      maskedValue: maskCard(digits),
      recommendation: 'Redact this card number immediately before sharing. If it is a real active card, consider it exposed and monitor for fraud.'
    }));
  }

  const seenAccounts = new Set();
  BANK_ACCOUNT_RE.lastIndex = 0;
  while ((match = BANK_ACCOUNT_RE.exec(text)) !== null) {
    const digits = match[0];
    if (seenAccounts.has(digits)) continue;
    if (seenCards.has(digits)) continue; // already classified as a card
    const windowStart = Math.max(0, match.index - 40);
    const contextWindow = text.slice(windowStart, match.index + digits.length + 10);
    if (!ACCOUNT_CONTEXT_RE.test(contextWindow)) continue; // require context to reduce false positives
    seenAccounts.add(digits);

    findings.push(buildFinding({
      category: 'BANK_ACCOUNT',
      description: 'Bank account number detected near account-related context.',
      severity: 'HIGH',
      confidence: 0.8,
      page,
      maskedValue: maskGeneric(digits),
      recommendation: 'Redact the bank account number or replace with a masked reference before sharing.'
    }));
  }

  return findings;
}

module.exports = { category: 'FINANCIAL', run, luhnCheck };
