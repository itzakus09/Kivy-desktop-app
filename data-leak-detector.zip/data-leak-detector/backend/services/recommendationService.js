'use strict';

const { severityWeight } = require('../schemas/finding.schema');

/**
 * Builds the excerpt set sent to Claude: full text if the document is
 * short, otherwise only paragraphs around rule-flagged spans (data
 * minimization per the privacy architecture).
 */
function buildAiContext(pages, ruleFindings, { maxChars, contextSentences }) {
  const totalChars = pages.reduce((s, p) => s + p.text.length, 0);
  if (totalChars <= maxChars) {
    return pages;
  }

  const findingsByPage = new Map();
  for (const f of ruleFindings) {
    if (f.page == null) continue;
    if (!findingsByPage.has(f.page)) findingsByPage.set(f.page, []);
    findingsByPage.get(f.page).push(f);
  }

  const excerptPages = [];
  for (const p of pages) {
    if (!findingsByPage.has(p.page)) continue;
    // naive sentence split; good enough for excerpt windowing
    const sentences = p.text.split(/(?<=[.!?])\s+/);
    // Since we don't track exact sentence offsets of matches here, take a
    // capped slice of the page around its first quarter of length as a
    // reasonable context sample rather than the entire (possibly huge) page.
    const take = Math.min(sentences.length, Math.max(contextSentences * 4, 6));
    excerptPages.push({ page: p.page, text: sentences.slice(0, take).join(' ') });
  }

  return excerptPages.length ? excerptPages : pages.slice(0, 1);
}

/**
 * Deduplicates and merges rule-based + AI recommendation strings,
 * sorting by the severity of the highest-severity finding that
 * generated each recommendation.
 */
function mergeRecommendations(findings, aiRecommendations = []) {
  const seen = new Set();
  const merged = [];

  // Rule/AI per-finding recommendations, most severe first
  const sortedFindings = [...findings].sort((a, b) => severityWeight(b.severity) - severityWeight(a.severity));
  for (const f of sortedFindings) {
    const key = f.recommendation.trim().toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    merged.push(f.recommendation);
  }

  // Top-level AI recommendations appended if not already covered
  for (const rec of aiRecommendations) {
    const key = String(rec).trim().toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    merged.push(rec);
  }

  return merged;
}

function categoryBreakdown(findings) {
  const groups = {
    Identity: ['PAN', 'AADHAAR', 'DATE_OF_BIRTH', 'IDENTITY_INFORMATION'],
    Financial: ['CREDIT_CARD', 'BANK_ACCOUNT', 'FINANCIAL_INFORMATION'],
    Credentials: ['PASSWORD', 'API_KEY', 'AUTH_TOKEN'],
    Contact: ['EMAIL', 'PHONE', 'ADDRESS'],
    Network: ['IP_ADDRESS', 'URL'],
    Other: ['CONTEXTUAL_PERSONAL_INFORMATION', 'CONFIDENTIAL_ORGANIZATIONAL_INFORMATION', 'OTHER']
  };
  const counts = { Identity: 0, Financial: 0, Credentials: 0, Contact: 0, Network: 0, Other: 0 };
  for (const f of findings) {
    const group = Object.keys(groups).find((g) => groups[g].includes(f.category)) || 'Other';
    counts[group] += 1;
  }
  return counts;
}

module.exports = { buildAiContext, mergeRecommendations, categoryBreakdown };
