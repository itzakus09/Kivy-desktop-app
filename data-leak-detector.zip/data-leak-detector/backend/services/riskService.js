'use strict';

const { severityWeight } = require('../schemas/finding.schema');

/**
 * Computes an overall 0-100 risk score and LOW/MEDIUM/HIGH/CRITICAL level
 * from the merged finding set, per the spec's scoring inputs: number of
 * findings, category sensitivity, confidence, severity, presence of
 * credentials/financial info, and repetition.
 */

const CATEGORY_WEIGHT = {
  API_KEY: 10, AUTH_TOKEN: 10, PASSWORD: 10,
  CREDIT_CARD: 9, BANK_ACCOUNT: 8, AADHAAR: 9, PAN: 7,
  FINANCIAL_INFORMATION: 8, IDENTITY_INFORMATION: 7,
  CONFIDENTIAL_ORGANIZATIONAL_INFORMATION: 7,
  DATE_OF_BIRTH: 5, ADDRESS: 5, PHONE: 4, EMAIL: 3,
  CONTEXTUAL_PERSONAL_INFORMATION: 5,
  IP_ADDRESS: 3, URL: 2, OTHER: 3
};

function scoreFinding(f) {
  const catWeight = CATEGORY_WEIGHT[f.category] ?? 4;
  const sevWeight = severityWeight(f.severity); // 1-4
  return catWeight * sevWeight * f.confidence;
}

function computeRisk(findings) {
  if (!findings.length) {
    return { riskScore: 0, riskLevel: 'LOW', breakdown: {} };
  }

  const hasCredentials = findings.some((f) => ['API_KEY', 'AUTH_TOKEN', 'PASSWORD'].includes(f.category));
  const hasFinancial = findings.some((f) => ['CREDIT_CARD', 'BANK_ACCOUNT', 'FINANCIAL_INFORMATION'].includes(f.category));

  // Repetition: same category appearing many times increases exposure risk
  // but with diminishing returns (log-scaled) so 50 emails isn't 50x worse
  // than 1.
  const countByCategory = {};
  for (const f of findings) {
    countByCategory[f.category] = (countByCategory[f.category] || 0) + 1;
  }

  let rawScore = 0;
  for (const f of findings) {
    const repetitionFactor = 1 + Math.log2(countByCategory[f.category]) * 0.15;
    rawScore += scoreFinding(f) * repetitionFactor;
  }

  if (hasCredentials) rawScore *= 1.25;
  if (hasFinancial) rawScore *= 1.15;

  // Normalize into 0-100 using a saturating curve so score growth slows
  // for documents with an extreme number of findings, rather than
  // linearly blowing past 100.
  const maxPossiblePerFinding = 10 * 4 * 1.0 * 1.25 * 1.15; // credential+financial ceiling
  const normalized = 100 * (1 - Math.exp(-rawScore / (maxPossiblePerFinding * 3)));
  const riskScore = Math.round(Math.min(100, Math.max(0, normalized)));

  let riskLevel = 'LOW';
  if (riskScore >= 80) riskLevel = 'CRITICAL';
  else if (riskScore >= 55) riskLevel = 'HIGH';
  else if (riskScore >= 25) riskLevel = 'MEDIUM';

  return {
    riskScore,
    riskLevel,
    breakdown: countByCategory
  };
}

module.exports = { computeRisk, scoreFinding };
