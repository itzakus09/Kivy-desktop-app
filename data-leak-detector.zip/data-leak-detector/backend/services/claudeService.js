'use strict';

const { logger } = require('../utils/logger');

const CLAUDE_API_URL = 'https://api.anthropic.com/v1/messages';
const ANTHROPIC_VERSION = '2023-06-01';

class ClaudeServiceError extends Error {
  constructor(message, code, recoverable = false) {
    super(message);
    this.code = code;
    this.recoverable = recoverable;
  }
}

const SYSTEM_PROMPT = `You are a security analyst reviewing document text for sensitive or personally identifiable information (PII).

You will be given excerpts of a document. Some sensitive data (emails, phone numbers, card numbers, IDs, credentials) has ALREADY been detected by a separate rule-based scanner — do NOT re-report anything that clearly matches those simple pattern categories. Instead, focus on what pattern matching cannot catch:

- Contextual personal information (e.g. information that identifies a specific person only when read in context)
- Sensitive identity information not caught by simple patterns
- Financial information described in prose rather than as a raw number
- Authentication-adjacent information (security questions, recovery hints, internal system names)
- Confidential organizational information (unreleased plans, internal-only data, trade secrets)
- Information that becomes sensitive because of surrounding context, even if individual facts seem harmless alone

Respond with ONLY valid JSON matching this exact schema, and nothing else — no markdown fences, no preamble:

{
  "overall_risk": "LOW" | "MEDIUM" | "HIGH" | "CRITICAL",
  "risk_score": <integer 0-100>,
  "findings": [
    {
      "category": "CONTEXTUAL_PERSONAL_INFORMATION" | "FINANCIAL_INFORMATION" | "IDENTITY_INFORMATION" | "CONFIDENTIAL_ORGANIZATIONAL_INFORMATION" | "OTHER",
      "description": "<what was found, without repeating the raw sensitive value verbatim>",
      "severity": "LOW" | "MEDIUM" | "HIGH" | "CRITICAL",
      "confidence": <float 0-1>,
      "page": <integer or null>,
      "recommendation": "<specific remediation action>"
    }
  ],
  "summary": "<2-3 sentence plain-language summary>",
  "recommendations": ["<top-level recommendation>", "..."]
}

Never include raw sensitive values (full card numbers, full IDs, full passwords) in your description or summary fields — describe what type of thing was found and where, not the value itself.`;

function buildUserPrompt(pages, ruleFindingSummary) {
  const pageBlocks = pages.map((p) => `--- Page ${p.page} ---\n${p.text}`).join('\n\n');
  return `Rule-based scanner already flagged ${ruleFindingSummary.count} items across categories: ${ruleFindingSummary.categories.join(', ') || 'none'}.

Analyze the following document excerpt(s) for anything additional per your instructions:

${pageBlocks}`;
}

function stripCodeFences(text) {
  return text.trim().replace(/^```(json)?/i, '').replace(/```$/, '').trim();
}

function validateClaudeResponse(parsed) {
  if (!parsed || typeof parsed !== 'object') return false;
  if (!['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'].includes(parsed.overall_risk)) return false;
  if (typeof parsed.risk_score !== 'number') return false;
  if (!Array.isArray(parsed.findings)) return false;
  if (typeof parsed.summary !== 'string') return false;
  if (!Array.isArray(parsed.recommendations)) return false;
  return true;
}

async function callClaudeOnce({ apiKey, model, maxTokens, pages, ruleFindingSummary }) {
  const body = {
    model,
    max_tokens: maxTokens,
    system: SYSTEM_PROMPT,
    messages: [
      { role: 'user', content: buildUserPrompt(pages, ruleFindingSummary) }
    ]
  };

  let response;
  try {
    response = await fetch(CLAUDE_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': ANTHROPIC_VERSION
      },
      body: JSON.stringify(body)
    });
  } catch (err) {
    throw new ClaudeServiceError('Network error contacting Claude API.', 'NETWORK_ERROR', true);
  }

  if (response.status === 401) {
    throw new ClaudeServiceError('Invalid or missing Anthropic API key.', 'INVALID_API_KEY', false);
  }
  if (response.status === 429) {
    throw new ClaudeServiceError('Claude API rate limit exceeded.', 'RATE_LIMITED', true);
  }
  if (response.status >= 500) {
    throw new ClaudeServiceError('Claude API is currently unavailable.', 'UPSTREAM_UNAVAILABLE', true);
  }
  if (!response.ok) {
    const text = await response.text().catch(() => '');
    throw new ClaudeServiceError(`Claude API error (${response.status}): ${text.slice(0, 200)}`, 'API_ERROR', false);
  }

  const data = await response.json();
  const textBlock = (data.content || []).find((b) => b.type === 'text');
  if (!textBlock) {
    throw new ClaudeServiceError('Claude returned no text content.', 'EMPTY_RESPONSE', true);
  }

  let parsed;
  try {
    parsed = JSON.parse(stripCodeFences(textBlock.text));
  } catch (err) {
    throw new ClaudeServiceError('Failed to parse Claude response as JSON.', 'PARSE_ERROR', true);
  }

  if (!validateClaudeResponse(parsed)) {
    throw new ClaudeServiceError('Claude response did not match the expected schema.', 'SCHEMA_INVALID', true);
  }

  return parsed;
}

/**
 * Calls Claude with a single retry on recoverable errors (parse failure,
 * rate limit, transient network/upstream issues) per the spec's
 * "gracefully handle timeout/rate-limit/invalid-JSON" requirement.
 */
async function analyzeWithClaude({ apiKey, model, maxTokens, pages, ruleFindingSummary, timeoutMs = 30000 }) {
  if (!apiKey) {
    throw new ClaudeServiceError('ANTHROPIC_API_KEY is not configured.', 'MISSING_API_KEY', false);
  }

  const withTimeout = (promise) => Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new ClaudeServiceError('Claude API request timed out.', 'TIMEOUT', true)), timeoutMs))
  ]);

  try {
    return await withTimeout(callClaudeOnce({ apiKey, model, maxTokens, pages, ruleFindingSummary }));
  } catch (err) {
    if (err instanceof ClaudeServiceError && err.recoverable) {
      logger.warn('Claude call failed, retrying once', { code: err.code });
      return await withTimeout(callClaudeOnce({ apiKey, model, maxTokens, pages, ruleFindingSummary }));
    }
    throw err;
  }
}

module.exports = { analyzeWithClaude, ClaudeServiceError, validateClaudeResponse, buildUserPrompt };
