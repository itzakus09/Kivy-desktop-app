'use strict';

/**
 * The PDF file itself is never uploaded to the backend (extraction happens
 * client-side in the Kivy app with PyMuPDF, per the privacy architecture).
 * This service instead handles the *text payload* the client sends:
 * validating its shape and preparing page-tagged chunks for the detectors
 * and for the Claude context-builder.
 */

const MAX_PAGES = 2000;
const MAX_CHARS_PER_PAGE = 200000;

class PdfTextValidationError extends Error {}

/**
 * @param {Array<{page:number, text:string}>} pages
 */
function validatePages(pages) {
  if (!Array.isArray(pages) || pages.length === 0) {
    throw new PdfTextValidationError('No page content received. The PDF may be empty or image-only.');
  }
  if (pages.length > MAX_PAGES) {
    throw new PdfTextValidationError(`Document has too many pages (${pages.length} > ${MAX_PAGES}).`);
  }
  for (const p of pages) {
    if (typeof p.page !== 'number') {
      throw new PdfTextValidationError('Each page entry must include a numeric page number.');
    }
    if (typeof p.text !== 'string') {
      throw new PdfTextValidationError('Each page entry must include text content (use an empty string for blank pages).');
    }
    if (p.text.length > MAX_CHARS_PER_PAGE) {
      throw new PdfTextValidationError(`Page ${p.page} exceeds the maximum supported text size.`);
    }
  }
  return true;
}

function totalCharCount(pages) {
  return pages.reduce((sum, p) => sum + (p.text ? p.text.length : 0), 0);
}

function isEffectivelyEmpty(pages) {
  return totalCharCount(pages) < 5;
}

module.exports = { validatePages, totalCharCount, isEffectivelyEmpty, PdfTextValidationError };
