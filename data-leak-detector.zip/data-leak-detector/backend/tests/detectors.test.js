'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const emailDetector = require('../detectors/emailDetector');
const phoneDetector = require('../detectors/phoneDetector');
const financialDetector = require('../detectors/financialDetector');
const identityDetector = require('../detectors/identityDetector');
const credentialDetector = require('../detectors/credentialDetector');
const networkDetector = require('../detectors/networkDetector');
const { runAllDetectors } = require('../detectors');
const { computeRisk } = require('../services/riskService');
const { luhnCheck } = require('../detectors/financialDetector');
const { verhoeffValidate } = require('../detectors/identityDetector');

test('email detector: valid email is found', () => {
  const findings = emailDetector.run('Contact us at hello@example.com for details.', 1);
  assert.equal(findings.length, 1);
  assert.equal(findings[0].category, 'EMAIL');
});

test('email detector: invalid email is not found', () => {
  const findings = emailDetector.run('This is not an email: hello@@@example', 1);
  assert.equal(findings.length, 0);
});

test('phone detector: plausible phone number with context gets high confidence', () => {
  const findings = phoneDetector.run('Please call my mobile: 98765 43210', 1);
  assert.equal(findings.length, 1);
  assert.ok(findings[0].confidence >= 0.85);
});

test('phone detector: random short digit sequence is ignored', () => {
  const findings = phoneDetector.run('Room 42', 1);
  assert.equal(findings.length, 0);
});

test('financial detector: valid Luhn card number is detected', () => {
  assert.equal(luhnCheck('4532015112830366'), true);
  const findings = financialDetector.run('Card number: 4532 0151 1283 0366', 1);
  assert.equal(findings.some((f) => f.category === 'CREDIT_CARD'), true);
});

test('financial detector: non-Luhn number is not flagged as a card', () => {
  const findings = financialDetector.run('Reference number: 1234567890123456', 1);
  assert.equal(findings.some((f) => f.category === 'CREDIT_CARD'), false);
});

test('identity detector: PAN-like pattern detected', () => {
  const findings = identityDetector.run('My PAN is ABCDE1234F for tax purposes.', 1);
  assert.equal(findings.some((f) => f.category === 'PAN'), true);
});

test('identity detector: Aadhaar with valid Verhoeff checksum flagged with high confidence', () => {
  // This is a synthetically constructed 12-digit string for testing only.
  const candidate = '234123412346';
  const isValid = verhoeffValidate(candidate);
  const findings = identityDetector.run(`Aadhaar number: ${candidate.slice(0,4)} ${candidate.slice(4,8)} ${candidate.slice(8)}`, 1);
  const aadhaarFinding = findings.find((f) => f.category === 'AADHAAR');
  assert.ok(aadhaarFinding, 'expected an Aadhaar finding given context keyword');
  if (isValid) assert.ok(aadhaarFinding.confidence >= 0.9);
});

test('credential detector: password key=value pattern detected', () => {
  const findings = credentialDetector.run('password: SuperSecret123!', 1);
  assert.equal(findings.some((f) => f.category === 'PASSWORD'), true);
});

test('credential detector: AWS-style access key detected', () => {
  const findings = credentialDetector.run('AKIAABCDEFGHIJKLMNOP', 1);
  assert.equal(findings.some((f) => f.category === 'API_KEY'), true);
});

test('network detector: IP address detected', () => {
  const findings = networkDetector.run('Server IP: 192.168.1.100', 1);
  assert.equal(findings.some((f) => f.category === 'IP_ADDRESS'), true);
});

test('network detector: URL with embedded token flagged HIGH', () => {
  const findings = networkDetector.run('Reset link: https://example.com/reset?token=abc123', 1);
  const f = findings.find((x) => x.category === 'URL');
  assert.equal(f.severity, 'HIGH');
});

test('false positive check: plain prose triggers no findings', () => {
  const findings = runAllDetectors([{ page: 1, text: 'The quick brown fox jumps over the lazy dog near the old oak tree.' }]);
  assert.equal(findings.length, 0);
});

test('risk service: no findings yields LOW risk and score 0', () => {
  const { riskScore, riskLevel } = computeRisk([]);
  assert.equal(riskScore, 0);
  assert.equal(riskLevel, 'LOW');
});

test('risk service: credential + financial findings push risk toward CRITICAL', () => {
  const pages = [{ page: 1, text: 'password: hunter2Secret\nCard: 4532 0151 1283 0366\nAadhaar: 2341 2341 2346' }];
  const findings = runAllDetectors(pages);
  const { riskScore, riskLevel } = computeRisk(findings);
  assert.ok(riskScore > 50, `expected elevated risk score, got ${riskScore}`);
  assert.ok(['HIGH', 'CRITICAL'].includes(riskLevel));
});
