'use strict';

const express = require('express');
const crypto = require('crypto');
const { validateScanInit } = require('../middleware/validation');
const { logger } = require('../utils/logger');

const router = express.Router();

// Completed reports kept only in memory as a short-lived fallback cache
// for clients that need to poll after a WS disconnect. Cleared on an
// interval — this is a convenience cache, not persistent storage.
const reportCache = new Map();
const REPORT_TTL_MS = 15 * 60 * 1000;

function cacheReport(report) {
  reportCache.set(report.scanId, { report, expiresAt: Date.now() + REPORT_TTL_MS });
}

setInterval(() => {
  const now = Date.now();
  for (const [id, entry] of reportCache.entries()) {
    if (entry.expiresAt < now) reportCache.delete(id);
  }
}, 60 * 1000).unref();

/**
 * REST fallback: allocate a scanId ahead of the WS handshake if the
 * client wants one up front (optional — the WS flow also generates its
 * own scanId if the client just sends start_scan directly).
 */
router.post('/init', validateScanInit, (req, res) => {
  const scanId = crypto.randomBytes(8).toString('hex');
  logger.info('Scan initialized via REST', { scanId, filename: req.body.meta.filename });
  res.json({ scanId });
});

/** REST fallback: fetch a completed report if the WS connection dropped. */
router.get('/:id/report', (req, res) => {
  const entry = reportCache.get(req.params.id);
  if (!entry) {
    return res.status(404).json({ error: 'Report not found or has expired.', code: 'NOT_FOUND' });
  }
  res.json(entry.report);
});

module.exports = { router, cacheReport };
