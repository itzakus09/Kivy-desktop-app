'use strict';

/**
 * Shared shape for a single finding, used by every detector, the Claude
 * response validator, and the recommendation/risk services. Keeping this
 * in one place is what lets rule-based and AI-based findings merge cleanly.
 */

const SEVERITIES = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];
const SOURCES = ['rule_based', 'ai', 'combined'];

const CATEGORIES = [
  'EMAIL', 'PHONE', 'CREDIT_CARD', 'BANK_ACCOUNT', 'PAN', 'AADHAAR',
  'IP_ADDRESS', 'URL', 'PASSWORD', 'API_KEY', 'AUTH_TOKEN',
  'DATE_OF_BIRTH', 'ADDRESS',
  // AI-only / contextual categories
  'CONTEXTUAL_PERSONAL_INFORMATION', 'FINANCIAL_INFORMATION',
  'IDENTITY_INFORMATION', 'CONFIDENTIAL_ORGANIZATIONAL_INFORMATION',
  'OTHER'
];

/**
 * @typedef {Object} Finding
 * @property {string} id
 * @property {string} category - one of CATEGORIES
 * @property {string} description
 * @property {string} severity - one of SEVERITIES
 * @property {number} confidence - 0..1
 * @property {number|null} page
 * @property {string} source - one of SOURCES
 * @property {string} maskedValue - never the raw sensitive value
 * @property {string} recommendation
 */

function isValidFinding(f) {
  if (!f || typeof f !== 'object') return false;
  if (typeof f.category !== 'string') return false;
  if (typeof f.description !== 'string') return false;
  if (!SEVERITIES.includes(f.severity)) return false;
  if (typeof f.confidence !== 'number' || f.confidence < 0 || f.confidence > 1) return false;
  if (!SOURCES.includes(f.source)) return false;
  return true;
}

function severityWeight(sev) {
  return { LOW: 1, MEDIUM: 2, HIGH: 3, CRITICAL: 4 }[sev] || 0;
}

module.exports = { SEVERITIES, SOURCES, CATEGORIES, isValidFinding, severityWeight };
