"""
Data model classes mirroring the backend's finding/report JSON shape,
so the UI layer works with typed objects instead of raw dicts.
"""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Finding:
    id: str
    category: str
    description: str
    severity: str  # LOW | MEDIUM | HIGH | CRITICAL
    confidence: float
    page: Optional[int]
    source: str  # rule_based | ai | combined
    masked_value: str
    recommendation: str

    @staticmethod
    def from_dict(d: dict) -> "Finding":
        return Finding(
            id=d.get("id", ""),
            category=d.get("category", "OTHER"),
            description=d.get("description", ""),
            severity=d.get("severity", "LOW"),
            confidence=float(d.get("confidence", 0.0)),
            page=d.get("page"),
            source=d.get("source", "rule_based"),
            masked_value=d.get("maskedValue", ""),
            recommendation=d.get("recommendation", ""),
        )


@dataclass
class ScanReport:
    scan_id: str
    filename: str
    completed_at: str
    risk_score: int
    risk_level: str
    categories: dict = field(default_factory=dict)
    findings: list = field(default_factory=list)
    recommendations: list = field(default_factory=list)
    ai_summary: Optional[str] = None

    @staticmethod
    def from_dict(d: dict) -> "ScanReport":
        return ScanReport(
            scan_id=d.get("scanId", ""),
            filename=d.get("filename", ""),
            completed_at=d.get("completedAt", ""),
            risk_score=int(d.get("riskScore", 0)),
            risk_level=d.get("riskLevel", "LOW"),
            categories=d.get("categories", {}),
            findings=[Finding.from_dict(f) for f in d.get("findings", [])],
            recommendations=d.get("recommendations", []),
            ai_summary=d.get("aiSummary"),
        )
