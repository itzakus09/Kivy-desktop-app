"""
Main dashboard screen: shows scan progress in real time and hosts the
ScanService for the currently running scan. On completion, hands the
report off to the results screen and switches to it.
"""

from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.popup import Popup

from services.scan_service import ScanService
from ui.components import ScanProgressBar
from utils.config import Config


class Dashboard(Screen):
    """Screen name: 'dashboard'"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = "dashboard"
        self.scan_service = None

        root = BoxLayout(orientation="vertical", padding=20, spacing=16)

        root.add_widget(Label(
            text=f"[b]{Config.APP_NAME}[/b]", markup=True, font_size=22,
            size_hint_y=None, height=36
        ))

        self.filename_label = Label(text="", size_hint_y=None, height=26)
        root.add_widget(self.filename_label)

        self.progress = ScanProgressBar()
        root.add_widget(self.progress)

        root.add_widget(BoxLayout())  # spacer
        self.add_widget(root)

    def start_scan(self, path: str):
        import os
        self.filename_label.text = f"Scanning: {os.path.basename(path)}"
        self.progress.update("Starting scan…", 0)

        self.scan_service = ScanService(
            on_status=self._on_status,
            on_complete=self._on_complete,
            on_error=self._on_error,
        )
        self.scan_service.run_scan(path)

    def _on_status(self, message: str, progress: int):
        self.progress.update(message, progress)

    def _on_complete(self, report):
        self.progress.update("Scan complete.", 100)
        results = self.manager.get_screen("results")
        results.display_report(report)
        self.manager.current = "results"

    def _on_error(self, message: str):
        self.progress.update("Scan failed.", 0)
        Popup(
            title="Scan Error",
            content=Label(text=message),
            size_hint=(0.75, 0.4)
        ).open()
