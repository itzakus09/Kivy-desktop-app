"""
Results dashboard: overall risk score, category breakdown, detailed
findings list, and prioritized recommendations. This is the screen the
spec's "Results Dashboard" section describes.
"""

from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button

from ui.components import RiskBadge, FindingCard, CategoryChip


class ResultsView(Screen):
    """Screen name: 'results'"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = "results"
        self._build_static_layout()

    def _build_static_layout(self):
        self.root_layout = BoxLayout(orientation="vertical", padding=16, spacing=12)

        # --- Header: risk badge + summary ---
        self.header_row = BoxLayout(size_hint_y=None, height=180, spacing=16)
        self.root_layout.add_widget(self.header_row)

        # --- Category breakdown ---
        self.category_row = GridLayout(cols=6, size_hint_y=None, height=90, spacing=8)
        self.root_layout.add_widget(self.category_row)

        # --- Findings (scrollable) ---
        self.root_layout.add_widget(Label(text="[b]Detailed Findings[/b]", markup=True, size_hint_y=None, height=28))
        self.findings_scroll = ScrollView(size_hint=(1, 1))
        self.findings_list = BoxLayout(orientation="vertical", size_hint_y=None, spacing=6)
        self.findings_list.bind(minimum_height=self.findings_list.setter("height"))
        self.findings_scroll.add_widget(self.findings_list)
        self.root_layout.add_widget(self.findings_scroll)

        # --- Recommendations ---
        self.root_layout.add_widget(Label(text="[b]Recommendations[/b]", markup=True, size_hint_y=None, height=28))
        self.recommendations_label = Label(text="", size_hint_y=None, halign="left", valign="top")
        self.recommendations_label.bind(texture_size=lambda inst, val: setattr(inst, "height", val[1]))
        self.root_layout.add_widget(self.recommendations_label)

        # --- Actions ---
        actions = BoxLayout(size_hint_y=None, height=48, spacing=10)
        new_scan_btn = Button(text="Scan Another Document")
        new_scan_btn.bind(on_release=self._on_new_scan)
        actions.add_widget(new_scan_btn)
        self.root_layout.add_widget(actions)

        self.add_widget(self.root_layout)

    def display_report(self, report):
        self.header_row.clear_widgets()
        self.category_row.clear_widgets()
        self.findings_list.clear_widgets()

        # Risk badge
        self.header_row.add_widget(RiskBadge(risk_score=report.risk_score, risk_level=report.risk_level))

        summary_box = BoxLayout(orientation="vertical", spacing=6)
        summary_box.add_widget(Label(
            text=f"[b]{report.filename}[/b]", markup=True, halign="left", size_hint_y=None, height=24
        ))
        summary_box.add_widget(Label(
            text=f"{len(report.findings)} issue(s) detected.", halign="left", size_hint_y=None, height=22
        ))
        if report.ai_summary:
            summary_box.add_widget(Label(
                text=report.ai_summary, halign="left", valign="top", font_size=13
            ))
        self.header_row.add_widget(summary_box)

        # Category breakdown chips
        for label, count in (report.categories or {}).items():
            self.category_row.add_widget(CategoryChip(label, count))

        # Findings list, most severe first
        severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
        for finding in sorted(report.findings, key=lambda f: severity_order.get(f.severity, 4)):
            self.findings_list.add_widget(FindingCard(finding))

        # Recommendations, numbered
        rec_lines = [f"{i+1}. {rec}" for i, rec in enumerate(report.recommendations)]
        self.recommendations_label.text = "\n".join(rec_lines) if rec_lines else "No specific recommendations — document looks clean."

    def _on_new_scan(self, _instance):
        self.manager.current = "upload"
