"""
Reusable UI building blocks shared across screens: risk badge, finding
card, and a category-count chip. Kept separate from the screens so the
dashboard/results views stay focused on layout and flow.
"""

from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.progressbar import ProgressBar
from kivy.graphics import Color, RoundedRectangle
from kivy.properties import StringProperty, NumericProperty

from utils.config import Config


class RiskBadge(BoxLayout):
    """Colored badge showing the overall risk score and level."""

    def __init__(self, risk_score: int = 0, risk_level: str = "LOW", **kwargs):
        super().__init__(orientation="vertical", size_hint=(None, None), size=(160, 160), **kwargs)
        color = Config.RISK_COLORS.get(risk_level, Config.RISK_COLORS["LOW"])

        with self.canvas.before:
            Color(*color)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size, radius=[16])
        self.bind(pos=self._update_bg, size=self._update_bg)

        self.add_widget(Label(text="Security Risk", font_size=14, bold=True))
        self.add_widget(Label(text=f"{risk_score} / 100", font_size=32, bold=True))
        self.add_widget(Label(text=risk_level, font_size=16, bold=True))

    def _update_bg(self, *_):
        self._bg.pos = self.pos
        self._bg.size = self.size


class ScanProgressBar(BoxLayout):
    """Progress bar + status label pair, updated in real time via WS events."""

    status_text = StringProperty("Idle")
    progress_value = NumericProperty(0)

    def __init__(self, **kwargs):
        super().__init__(orientation="vertical", spacing=6, size_hint_y=None, height=60, **kwargs)
        self._label = Label(text=self.status_text, size_hint_y=None, height=24)
        self._bar = ProgressBar(max=100, value=self.progress_value, size_hint_y=None, height=20)
        self.add_widget(self._label)
        self.add_widget(self._bar)
        self.bind(status_text=self._on_status, progress_value=self._on_progress)

    def _on_status(self, _instance, value):
        self._label.text = value

    def _on_progress(self, _instance, value):
        self._bar.value = value

    def update(self, message: str, progress: int):
        self.status_text = message
        self.progress_value = progress


class FindingCard(BoxLayout):
    """One row in the findings list: severity icon, category, description, page."""

    def __init__(self, finding, **kwargs):
        super().__init__(orientation="vertical", size_hint_y=None, height=90, padding=8, spacing=2, **kwargs)
        icon = Config.SEVERITY_ICONS.get(finding.severity, "⚪")
        color = Config.RISK_COLORS.get(finding.severity, (1, 1, 1, 1))

        with self.canvas.before:
            Color(*color, 0.15)
            self._bg = RoundedRectangle(pos=self.pos, size=self.size, radius=[8])
        self.bind(pos=self._update_bg, size=self._update_bg)

        header = BoxLayout(size_hint_y=None, height=24)
        page_text = f"Page {finding.page}" if finding.page else "Page —"
        header.add_widget(Label(
            text=f"{icon} {finding.severity}   {finding.category.replace('_', ' ').title()}",
            bold=True, halign="left", valign="middle"
        ))
        header.add_widget(Label(text=f"{page_text}   {int(finding.confidence * 100)}% conf.", size_hint_x=0.4))
        self.add_widget(header)

        self.add_widget(Label(text=finding.description, halign="left", valign="top", font_size=13))
        self.add_widget(Label(
            text=f"→ {finding.recommendation}", halign="left", valign="top",
            font_size=12, italic=True, color=(0.75, 0.75, 0.75, 1)
        ))

    def _update_bg(self, *_):
        self._bg.pos = self.pos
        self._bg.size = self.size


class CategoryChip(BoxLayout):
    """Small labeled count, e.g. 'Financial   3'."""

    def __init__(self, label: str, count: int, **kwargs):
        super().__init__(orientation="vertical", size_hint=(None, None), size=(100, 70), **kwargs)
        self.add_widget(Label(text=str(count), font_size=22, bold=True))
        self.add_widget(Label(text=label, font_size=12))
