"""
File selection screen: choose a PDF, see basic file info, and trigger a
scan. Kept intentionally simple — validation feedback and error states
are surfaced here immediately, before any network activity starts.
"""

import os

from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.popup import Popup

from utils.validators import validate_pdf_path, FileValidationError
from utils.config import Config


class UploadView(Screen):
    """
    Screen name: 'upload'
    On successful selection + validation, calls
    `app.root.get_screen('dashboard').set_selected_file(path)` and
    switches to the dashboard screen.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = "upload"
        self.selected_path = None

        root = BoxLayout(orientation="vertical", padding=20, spacing=12)

        root.add_widget(Label(
            text=f"[b]{Config.APP_NAME}[/b]", markup=True, font_size=24,
            size_hint_y=None, height=40
        ))
        root.add_widget(Label(
            text="Select a PDF document to scan for sensitive information.",
            size_hint_y=None, height=30
        ))

        self.file_chooser = FileChooserListView(filters=["*.pdf"], path=os.path.expanduser("~"))
        self.file_chooser.bind(selection=self._on_selection)
        root.add_widget(self.file_chooser)

        self.file_info_label = Label(text="No file selected.", size_hint_y=None, height=30)
        root.add_widget(self.file_info_label)

        button_row = BoxLayout(size_hint_y=None, height=50, spacing=10)
        self.scan_button = Button(text="Scan Document", disabled=True)
        self.scan_button.bind(on_release=self._on_scan_pressed)
        button_row.add_widget(self.scan_button)
        root.add_widget(button_row)

        self.add_widget(root)

    def _on_selection(self, _instance, selection):
        if not selection:
            self.selected_path = None
            self.scan_button.disabled = True
            self.file_info_label.text = "No file selected."
            return

        path = selection[0]
        try:
            validate_pdf_path(path)
        except FileValidationError as exc:
            self.selected_path = None
            self.scan_button.disabled = True
            self.file_info_label.text = f"⚠ {exc}"
            return

        self.selected_path = path
        self.scan_button.disabled = False
        size_kb = os.path.getsize(path) / 1024
        self.file_info_label.text = f"Selected: {os.path.basename(path)} ({size_kb:.1f} KB)"

    def _on_scan_pressed(self, _instance):
        if not self.selected_path:
            return
        dashboard = self.manager.get_screen("dashboard")
        dashboard.start_scan(self.selected_path)
        self.manager.current = "dashboard"

    def show_error_popup(self, message: str):
        Popup(
            title="Error",
            content=Label(text=message),
            size_hint=(0.7, 0.4)
        ).open()
