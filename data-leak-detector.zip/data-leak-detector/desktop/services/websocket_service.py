"""
Python WebSocket client that talks to the Node.js backend. Runs the
websocket connection on a background thread so the Kivy event loop and
UI never freeze during a scan, and marshals incoming events back onto
the main thread via Kivy's Clock so widgets can be updated safely.
"""

import json
import threading

import websocket  # websocket-client package

from kivy.clock import Clock

from utils.config import Config


class ScanWebSocketClient:
    """
    Usage:
        client = ScanWebSocketClient(on_event=callback)
        client.connect()
        client.start_scan(meta, pages)
        ...
        client.close()

    `on_event` is called (on the main/UI thread) with the parsed event
    dict for every message the server sends.
    """

    def __init__(self, on_event, on_error=None):
        self.on_event = on_event
        self.on_error = on_error
        self._ws = None
        self._thread = None
        self._connected = threading.Event()

    def connect(self, timeout: float = 5.0) -> bool:
        def _run():
            self._ws = websocket.WebSocketApp(
                Config.BACKEND_WS_URL,
                on_open=self._handle_open,
                on_message=self._handle_message,
                on_error=self._handle_error,
                on_close=self._handle_close,
            )
            self._ws.run_forever()

        self._thread = threading.Thread(target=_run, daemon=True)
        self._thread.start()
        return self._connected.wait(timeout)

    def _handle_open(self, ws):
        self._connected.set()

    def _handle_message(self, ws, message):
        try:
            data = json.loads(message)
        except json.JSONDecodeError:
            return
        # Marshal back onto the Kivy main thread — never touch widgets
        # directly from the websocket thread.
        Clock.schedule_once(lambda dt: self.on_event(data))

    def _handle_error(self, ws, error):
        if self.on_error:
            Clock.schedule_once(lambda dt: self.on_error(str(error)))

    def _handle_close(self, ws, close_status_code, close_msg):
        self._connected.clear()

    def start_scan(self, meta: dict, pages: list):
        if not self._ws or not self._connected.is_set():
            raise ConnectionError("WebSocket is not connected to the backend.")
        payload = json.dumps({"type": "start_scan", "meta": meta, "pages": pages})
        self._ws.send(payload)

    def close(self):
        if self._ws:
            self._ws.close()
        self._connected.clear()

    @property
    def is_connected(self) -> bool:
        return self._connected.is_set()
