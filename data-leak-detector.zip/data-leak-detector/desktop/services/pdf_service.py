"""
Local PDF text extraction using PyMuPDF (fitz). Runs entirely on the
client — the raw PDF file is never sent to the backend, per the privacy
architecture. Only the extracted, page-tagged text leaves this module.
"""

from typing import List, Dict

import pymupdf as fitz  # PyMuPDF (import name updated from the deprecated 'fitz' alias)


class PdfExtractionError(Exception):
    pass


def extract_pages(path: str) -> List[Dict]:
    """
    Returns a list of {"page": int, "text": str} dicts, one per page,
    1-indexed to match how findings reference pages elsewhere in the app.
    """
    try:
        doc = fitz.open(path)
    except Exception as exc:  # PyMuPDF raises its own exception types
        raise PdfExtractionError(f"Could not open PDF: {exc}") from exc

    if doc.is_encrypted:
        # Attempt an empty-password unlock (common for "protected but not
        # really secured" PDFs); if that fails, surface a clear error
        # rather than silently returning nothing.
        if not doc.authenticate(""):
            doc.close()
            raise PdfExtractionError(
                "This PDF is password-protected and could not be opened automatically."
            )

    pages = []
    try:
        for i, page in enumerate(doc, start=1):
            text = page.get_text("text") or ""
            pages.append({"page": i, "text": text})
    finally:
        doc.close()

    return pages


def is_image_only(pages: List[Dict]) -> bool:
    """
    Heuristic: if extracted text across all pages is negligible, this is
    almost certainly a scanned/image-only PDF with no embedded text layer.
    OCR is intentionally out of scope for v1 — flagged clearly to the user
    instead of silently producing an empty report.
    """
    total_chars = sum(len(p["text"].strip()) for p in pages)
    return total_chars < 5
