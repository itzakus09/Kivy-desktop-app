"""
Orchestrates a full scan: local extraction -> local optimistic pre-scan
-> send to backend over WebSocket -> collect progress events -> build a
ScanReport for the results screen.

This is the layer the UI screens talk to; it hides both PyMuPDF and the
WebSocket client behind a simple callback-based API.
"""

import os
import re
from typing import Callable, Optional

from models.findings import ScanReport
from services.pdf_service import extract_pages, is_image_only, PdfExtractionError
from services.websocket_service import ScanWebSocketClient
from utils.config import Config
from utils.validators import validate_pdf_path, FileValidationError

# A deliberately small mirror of the backend's email pattern, used only
# for instant "we found something" UI feedback before the backend's
# authoritative rule scan runs. The backend result is what's actually
# displayed in the report.
_QUICK_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")


class ScanService:
    """
    Callbacks:
      on_status(message: str, progress: int)  -- for the progress bar/label
      on_complete(report: ScanReport)
      on_error(message: str)
    """

    def __init__(
        self,
        on_status: Callable[[str, int], None],
        on_complete: Callable[[ScanReport], None],
        on_error: Callable[[str], None],
    ):
        self.on_status = on_status
        self.on_complete = on_complete
        self.on_error = on_error
        self._client: Optional[ScanWebSocketClient] = None

    def quick_local_preview(self, pages: list) -> int:
        """Fast client-side count used only for optimistic UI, not the report."""
        count = 0
        for p in pages:
            count += len(_QUICK_EMAIL_RE.findall(p["text"]))
        return count

    def run_scan(self, path: str):
        try:
            validate_pdf_path(path)
        except FileValidationError as exc:
            self.on_error(str(exc))
            return

        self.on_status("Extracting text from PDF…", 10)
        try:
            pages = extract_pages(path)
        except PdfExtractionError as exc:
            self.on_error(str(exc))
            return

        if is_image_only(pages):
            self.on_error(
                "This PDF appears to contain no extractable text (it may be scanned/image-only). "
                "OCR support is not yet available."
            )
            return

        self.on_status("Connecting to scanning service…", 20)
        self._client = ScanWebSocketClient(on_event=self._handle_event, on_error=self._handle_ws_error)
        if not self._client.connect():
            self.on_error(
                f"Could not connect to the backend at {Config.BACKEND_WS_URL}. "
                "Is the backend server running?"
            )
            return

        meta = {"filename": os.path.basename(path), "sizeBytes": os.path.getsize(path)}
        try:
            self._client.start_scan(meta, pages)
        except ConnectionError as exc:
            self.on_error(str(exc))

    def _handle_event(self, event: dict):
        name = event.get("event")
        progress = event.get("progress", 0)
        message = event.get("message", "")

        if name == "error":
            self.on_error(message)
            self._cleanup()
            return

        if name == "scan_completed":
            report = ScanReport.from_dict(event.get("data", {}))
            self.on_complete(report)
            self._cleanup()
            return

        # Any other event is just a progress update for the status bar.
        self.on_status(message, progress)

    def _handle_ws_error(self, message: str):
        self.on_error(f"Connection error: {message}")
        self._cleanup()

    def _cleanup(self):
        if self._client:
            self._client.close()
            self._client = None
