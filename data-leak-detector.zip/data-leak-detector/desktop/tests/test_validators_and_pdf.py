"""
Tests for client-side validation and PDF extraction. Run with:
    python -m pytest tests/  (or: python -m unittest discover tests)
"""

import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.validators import validate_pdf_path, FileValidationError
from services.pdf_service import extract_pages, is_image_only, PdfExtractionError

import pymupdf as fitz


def _make_pdf(path, text="Contact: test@example.com"):
    doc = fitz.open()
    page = doc.new_page()
    if text:
        page.insert_text((72, 72), text)
    doc.save(path)
    doc.close()


class ValidatorTests(unittest.TestCase):
    def test_rejects_missing_file(self):
        with self.assertRaises(FileValidationError):
            validate_pdf_path("/tmp/does_not_exist_12345.pdf")

    def test_rejects_wrong_extension(self):
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as f:
            f.write(b"not a pdf")
            path = f.name
        try:
            with self.assertRaises(FileValidationError):
                validate_pdf_path(path)
        finally:
            os.remove(path)

    def test_rejects_corrupted_pdf_header(self):
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as f:
            f.write(b"NOT A REAL PDF HEADER")
            path = f.name
        try:
            with self.assertRaises(FileValidationError):
                validate_pdf_path(path)
        finally:
            os.remove(path)

    def test_accepts_valid_pdf(self):
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as f:
            path = f.name
        try:
            _make_pdf(path)
            validate_pdf_path(path)  # should not raise
        finally:
            os.remove(path)


class PdfExtractionTests(unittest.TestCase):
    def test_extracts_text_with_page_numbers(self):
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as f:
            path = f.name
        try:
            _make_pdf(path, text="Contact: test@example.com")
            pages = extract_pages(path)
            self.assertEqual(len(pages), 1)
            self.assertEqual(pages[0]["page"], 1)
            self.assertIn("test@example.com", pages[0]["text"])
        finally:
            os.remove(path)

    def test_image_only_pdf_detected_as_empty(self):
        with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as f:
            path = f.name
        try:
            _make_pdf(path, text="")  # blank page, no text layer
            pages = extract_pages(path)
            self.assertTrue(is_image_only(pages))
        finally:
            os.remove(path)

    def test_open_nonexistent_pdf_raises(self):
        with self.assertRaises(PdfExtractionError):
            extract_pages("/tmp/definitely_missing_9999.pdf")


if __name__ == "__main__":
    unittest.main()
