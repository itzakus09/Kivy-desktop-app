"""
Entry point for the Personal Data Leak Detector desktop application.
Wires the three screens (upload -> dashboard -> results) into a
ScreenManager and launches the Kivy app.
"""

from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, FadeTransition
from kivy.core.window import Window

from ui.upload_view import UploadView
from ui.dashboard import Dashboard
from ui.results_view import ResultsView
from utils.config import Config


class RootManager(ScreenManager):
    def __init__(self, **kwargs):
        super().__init__(transition=FadeTransition(), **kwargs)
        self.add_widget(UploadView())
        self.add_widget(Dashboard())
        self.add_widget(ResultsView())
        self.current = "upload"


class DataLeakDetectorApp(App):
    title = Config.APP_NAME

    def build(self):
        Window.size = (1000, 720)
        Window.clearcolor = (0.07, 0.07, 0.08, 1)
        return RootManager()


if __name__ == "__main__":
    DataLeakDetectorApp().run()
