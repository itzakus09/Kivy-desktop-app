"""
Central configuration for the desktop client. Values are read from
environment variables (or a local .env via python-dotenv if present) so
the backend URL, WebSocket URL, and upload limits can be changed without
touching code.
"""

import os

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    # python-dotenv is optional; the app still runs with plain env vars
    # or the defaults below.
    pass


class Config:
    BACKEND_HTTP_URL = os.environ.get("BACKEND_HTTP_URL", "http://localhost:4000")
    BACKEND_WS_URL = os.environ.get("BACKEND_WS_URL", "ws://localhost:4000/ws")

    MAX_FILE_SIZE_MB = int(os.environ.get("MAX_FILE_SIZE_MB", "25"))
    ALLOWED_EXTENSIONS = {".pdf"}

    APP_NAME = "Personal Data Leak Detector"
    APP_VERSION = "1.0.0"

    # Risk level -> color mapping used across the UI (RGBA, 0-1 floats)
    RISK_COLORS = {
        "LOW": (0.20, 0.70, 0.35, 1),
        "MEDIUM": (0.95, 0.70, 0.10, 1),
        "HIGH": (0.90, 0.40, 0.10, 1),
        "CRITICAL": (0.80, 0.10, 0.15, 1),
    }

    SEVERITY_ICONS = {
        "LOW": "🟢",
        "MEDIUM": "🟡",
        "HIGH": "🟠",
        "CRITICAL": "🔴",
    }
