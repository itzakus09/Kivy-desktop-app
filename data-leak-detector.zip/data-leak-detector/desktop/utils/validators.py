"""
Client-side file validation, run before any extraction or network call.
Mirrors the backend's validation rules so users get instant feedback
without a round trip.
"""

import os

from utils.config import Config


class FileValidationError(Exception):
    pass


def validate_pdf_path(path: str) -> None:
    if not path:
        raise FileValidationError("No file selected.")

    if not os.path.isfile(path):
        raise FileValidationError("The selected file could not be found.")

    ext = os.path.splitext(path)[1].lower()
    if ext not in Config.ALLOWED_EXTENSIONS:
        raise FileValidationError(f"Unsupported file type '{ext}'. Please select a PDF file.")

    size_mb = os.path.getsize(path) / (1024 * 1024)
    if size_mb > Config.MAX_FILE_SIZE_MB:
        raise FileValidationError(
            f"File is {size_mb:.1f}MB, which exceeds the {Config.MAX_FILE_SIZE_MB}MB limit."
        )

    # Cheap corruption check: PDFs must start with the %PDF- signature.
    with open(path, "rb") as f:
        header = f.read(5)
    if header != b"%PDF-":
        raise FileValidationError("This file does not appear to be a valid PDF (missing PDF header).")
